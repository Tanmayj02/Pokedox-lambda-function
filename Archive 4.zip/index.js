const { apiConstants } = require("./src/Constants");
const queryItem = require("./src/Pokemon");
const { buildResponse } = require("./src/Utils");

const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
try {
        switch (true) {
                case event.resource === apiConstants.HTTP_PATHS.pokemonById:
                const data = await queryItem();
                return buildResponse(apiConstants.HTTP_STATUS.CODE_200,data);
                case event.resource === apiConstants.HTTP_PATHS.pokemon:
                const data1 = await queryItem();
                return buildResponse(apiConstants.HTTP_STATUS.CODE_200,data1); 
                default:
                return buildResponse(apiConstants.HTTP_STATUS.CODE_404, "404 path not found");       
        }
}
  catch (err) {
    return { error: err }
  }
}

const pokemonTable = require("./Schema");

module.exports = {
  ...pokemonTable
};
const pokemonContent = {
    category: 'Field',
    id: 'id',
    name: 'name'  
}

const pokemonTable = {
    name: 'Pokedex_test',
    pokemonDatails: {
      abilities: '',
      baseExperience: '',
      height: '',
      id: '',
      name: '',
      sprites: '',
      stats: '',
      types: '',
      weight: ''
    },
    abilityDetails: {
    effect_entries: '',
    id: '',
    name: '',  
    pokemon: '' 
    },
    typeDetails: {
    id: '',
    name: '',
    pokemon: '',
    }
  };

module.exports = {
    pokemonTable
  };

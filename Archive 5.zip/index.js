const { HTTP_PATHS, HTTP_STATUS } = require("./src/Constants/index");
const queryItem = require("./src/Pokemon");
const { buildResponse } = require("./src/Utils");

let response = {
    responseStatus,
    responseBody
  };

exports.handler = async (event, context) => {
try {
        switch (true) {
                case event.resource === HTTP_PATHS.pokemonById:
                responseStatus = HTTP_PATHS.CODE_200;
                response.responseBody = await queryItem();
                break;
                case event.resource === HTTP_PATHS.pokemon:
                responseStatus = HTTP_PATHS.CODE_200;
                response.responseBody = await queryItem();
                break;
                default:
                return buildResponse(HTTP_STATUS.CODE_404, "404 path not found");       
        }

        return response;
}
  catch (err) {
    return { error: err }
  }
}

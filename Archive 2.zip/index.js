const { pokemonTable, apiConstants } = require("./src/Constants");
const queryItem = require("./src/Pokemon");

const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
try {
        let response;
        switch (true) {
                case event.resource == '/pokemon/{id}':
                const data = await queryItem();
                response = {
                'statusCode': 200,
                'body': JSON.stringify(data)
                }
                return response
                case event.resource == '/pokemon':
                const data1 = await queryItem();
                response = {
                'statusCode': 200,
                'body': JSON.stringify(data1)
                }
                return response           
    }
}
  catch (err) {
    return { error: err }
  }
}
